======================================================================
                   FastCopy  ver1.99r4                 2009/08/11
                                                 SHIROUZU Hiroaki
======================================================================

	FastCopy is the Fastest Copy/Delete Software on Windows.

	It can copy/delete unicode and over MAX_PATH(260byte) pathname files.

	It always run by multi-threading.

	It don't use MFC, it is compact and don't requre mfcxx.dll.

	FastCopy is BSD license, you can modify and use.

License:
	---------------------------------------------------------------
	 Copyright 2004-2009 SHIROUZU Hiroaki All rights reserved.

	Redistribution and use in source and binary forms, with or
	without modification, are permitted provided that the following
	conditions are met:

	1.	Redistributions of source code must retain the above
		copyright notice, this list of conditions and the following
		disclaimer.

	2.	Redistributions in binary form must reproduce the above
		copyright notice, this list of conditions and the following
		disclaimer in the documentation and/or other materials
		provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY SHIROUZU Hiroaki ``AS IS'' AND ANY
	EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
	PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SHIROUZU
	Hiroaki OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
	INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
	OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
	THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	---------------------------------------------------------------

Usage�F
	Please see fastcopy.chm

Build:
	FastCopy/Install/ShellExt ... VC4.1
	ShellExt64 ... x64 compiler

